package com.example.tugasbutton

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnScore1 = findViewById<Button>(R.id.btnScore1)
        val btnScore2 = findViewById<Button>(R.id.btnScore2)
        val tvScore = findViewById<TextView>(R.id.tvScore)


        playRound(tvScore)

        btnScore1.setOnClickListener {
            checkAnswer(btnScore1.text.toString().toInt(), btnScore2.text.toString().toInt(), tvScore)
        }

        btnScore2.setOnClickListener {
            checkAnswer(btnScore2.text.toString().toInt(), btnScore1.text.toString().toInt(), tvScore)
        }

        findViewById<Button>(R.id.btnReset).setOnClickListener {
            score = 0
            tvScore.text = "Points: $score"
            playRound(tvScore)
        }
    }

    private fun playRound(tvScore: TextView?) {
        val leftVal = randomNumber()
        val rightVal = randomNumber()

        findViewById<Button>(R.id.btnScore1).text = leftVal.toString()
        findViewById<Button>(R.id.btnScore2).text = rightVal.toString()

        if (tvScore != null) {
            tvScore.text = "Points: $score"
        }
    }

    private fun randomNumber(): Int {
        return Random.nextInt(1, 101)
    }

    private fun checkAnswer(selectedNumber: Int, otherNumber: Int, tvScore: TextView) {
        if (selectedNumber > otherNumber) {
            score++
            tvScore.text = "Points: $score"
        }
        playRound(tvScore)
    }

}